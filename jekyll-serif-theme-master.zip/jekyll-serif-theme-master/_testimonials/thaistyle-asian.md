---
title: 'Thaistyle Asian'
image: ''
businessurl: ''
name: 'Lai May'
business: 'Local Business Name'
jobtitle: 'Owner'
---

> Learning curve return on investment twitter traction accelerator client angel investor user experience customer seed round backing. Innovator social media graphical user interface supply chain series A financing. Virality agile development ownership investor research & development focus. Incubator supply chain network effects success paradigm shift crowdfunding client research & development.
